"""
Package: simulators
-------------------
This package contains simulator modules for testing components of the Mission Planner project,
such as the MAVLink server emulator.
"""

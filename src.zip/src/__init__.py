"""
Package: src
-------------------
This package contains the main source code for the Mission Planner project.
It includes modules for configuration, interfaces, state management, GUI, and more.
"""
"""
Package: gui
-------------------
This package contains the graphical user interface components for the Mission Planner project.
Modules include MonitorGUI, ConfigEditorFrame, and other GUI utilities.
"""
